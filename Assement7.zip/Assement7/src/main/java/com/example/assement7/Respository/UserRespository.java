package com.example.assement7.Respository;

import com.example.assement7.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
 public interface UserRespository extends JpaRepository <User, Integer> {

 User findAllById (Integer id);
 User findAllByUsername(String username);
 User findAllByEmail (String emil);

 List<User>findAllByRole(String role);
 List<User> findAllByAgeGreaterThanEqual (Integer age);
}
