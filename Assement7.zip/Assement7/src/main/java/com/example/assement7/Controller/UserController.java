package com.example.assement7.Controller;

import com.example.assement7.Dto.ApiResponse;
import com.example.assement7.Model.User;
import com.example.assement7.Service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController @RequestMapping("/api/v1")
public class UserController {
    private UserService  userService ;

    public UserController (UserService userService) {

        this.userService = userService;
    }

    @GetMapping("/get")
    public ResponseEntity getUser() {
        return ResponseEntity.status(200).body(userService.getUser());
    }

    @PostMapping("/add")
    public ResponseEntity addUser(@RequestBody @Valid User user) {
        userService.addUser(user);
        return ResponseEntity.status(200).body(new ApiResponse("User Added!"));
    }

    @PutMapping("/update/{index}")
    public ResponseEntity updateUser(@PathVariable Integer id, @RequestBody @Valid User user) {
        userService.updateUser(id, user);
            return ResponseEntity.status(200).body(new ApiResponse("User update!"));
        }

    @DeleteMapping ("/delete/{index}")
    public ResponseEntity deleteUser(@PathVariable Integer id) {
        userService.deleteUser(id);
        return ResponseEntity.status(200).body(new ApiResponse("User Delete!"));
    }
    @GetMapping("/check/password")
    public ResponseEntity Check(@RequestBody String username , @PathVariable String password)
    {
        return ResponseEntity.status(200).body(userService.Check(username,password));
    }

    @GetMapping("/getByEmail/")
    public ResponseEntity getByEmail(@RequestBody String email)
    {
        return ResponseEntity.status(200).body(userService.getByEmail(email));
    }

    @GetMapping("/getByRole/")
    public ResponseEntity getByRole(@RequestBody String role)
    {
        return ResponseEntity.status(200).body(userService.getByRole(role));
    }
    @GetMapping("/getByAge/")
    public ResponseEntity getByAge(@RequestBody Integer age)
    {
        return ResponseEntity.status(200).body(userService.getByAge(age));
    }

}
