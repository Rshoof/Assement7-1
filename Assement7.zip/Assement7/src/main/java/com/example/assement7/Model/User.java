package com.example.assement7.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @AllArgsConstructor @Entity @NoArgsConstructor
public class User {
    @NotNull(message = "Should be not null")
    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY )
    private Integer id;

    @NotEmpty(message = "Should be not null")
    @Size(min = 4 , max = 20 ,message = " username should be more than 4 ")
    @Column(columnDefinition = "unique")
    private String username;

    @NotEmpty(message = "Should be not null")
    private Integer password;

    @NotEmpty(message = "Should be not null")
    @Column(columnDefinition = "unique")
    @Email
    private String email;
    @NotEmpty(message = "Should be not null")
    @Pattern(regexp = "check(user or admin)")
    private String role;
    @NotNull (message = " Should be not null")
    private Integer age;
}
